package org.devicecheck.scanner

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var last: ScanResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(box) })
        home()
    }

    private fun text(s: String, size: Float = 15f, bold: Boolean = false, color: Int = Color.BLACK) {
        box.addView(TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 10, 0, 10)
        })
    }

    private fun button(label: String, onClick: () -> Unit) {
        box.addView(Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        })
    }

    private fun home() {
        box.removeAllViews()
        text("DeviceCheck", 26f, true)
        text(
            "Scans this phone for stalkerware and spyware warning signs: spy-style apps, hidden apps, " +
                "apps with Accessibility/Device Admin power, sideloaded apps and risky settings.\n\n" +
                "Everything stays on this phone. This app has no internet permission."
        )
        text(
            "Before you remove anything: if someone may be monitoring you, or this phone was held by " +
                "police or anyone else, do NOT factory reset it. Resetting destroys evidence and may alert the person. " +
                "Save the report and get help first.",
            14f, false, Color.parseColor("#B26A00")
        )
        text(
            "Limits: this finds common stalkerware and suspicious setups. It cannot find advanced spyware " +
                "(Pegasus-class). For that, ask Access Now (accessnow.org/help) for a forensic check.",
            13f, false, Color.DKGRAY
        )
        button("Scan this phone") { runScan() }
    }

    private fun runScan() {
        box.removeAllViews()
        text("Scanning...", 18f, true)
        Thread {
            val r = try {
                Scanner.scan(this)
            } catch (e: Exception) {
                null
            }
            runOnUiThread { if (r == null) home() else render(r) }
        }.start()
    }

    private fun render(r: ScanResult) {
        last = r
        box.removeAllViews()
        val color = when (r.level) {
            "HIGH" -> Color.parseColor("#C62828")
            "MEDIUM" -> Color.parseColor("#E08900")
            else -> Color.parseColor("#2E7D32")
        }
        text("Result: ${r.level} concern", 24f, true, color)
        text("${r.scanned} apps checked.", 13f, false, Color.DKGRAY)

        if (r.device.isNotEmpty()) {
            text("Phone settings", 18f, true)
            r.device.forEach { text("• $it") }
        }
        if (r.apps.isNotEmpty()) {
            text("Apps to review", 18f, true)
            r.apps.forEach { a ->
                text("${a.label}  (score ${a.score})", 16f, true)
                text(a.reasons.joinToString("\n") { "• $it" }, 14f)
                if (a.score >= 4) {
                    button("Open settings for ${a.label}") {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                        )
                    }
                }
            }
        }
        if (r.device.isEmpty() && r.apps.isEmpty()) {
            text("No known warning signs found. This does not prove the phone is clean.")
        }

        text("Next steps", 18f, true)
        button("Share / save report") {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, last?.asText() ?: "")
                    }, "Share report"
                )
            )
        }
        button("Review Accessibility apps") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("Review Device Admin apps") { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        button("Scan again") { runScan() }
        button("Back") { home() }
        box.visibility = View.VISIBLE
    }
}
