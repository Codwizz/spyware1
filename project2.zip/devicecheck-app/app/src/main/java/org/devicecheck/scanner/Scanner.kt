package org.devicecheck.scanner

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import java.io.File
import java.time.LocalDate

class AppFlag(val pkg: String, val label: String, val score: Int, val reasons: List<String>)

class ScanResult(val apps: List<AppFlag>, val device: List<String>, val scanned: Int) {
    private val top get() = apps.maxOfOrNull { it.score } ?: 0
    val level: String
        get() = when {
            top >= 8 -> "HIGH"
            top >= 4 || device.size >= 2 -> "MEDIUM"
            else -> "LOW"
        }

    fun asText(): String = buildString {
        appendLine("DeviceCheck report - level: $level ($scanned apps checked)")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
        device.forEach { appendLine("- $it") }
        apps.forEach { a ->
            appendLine("* ${a.label} (${a.pkg}) score ${a.score}")
            a.reasons.forEach { appendLine("    - $it") }
        }
    }
}

object Scanner {
    private val SENSITIVE = setOf(
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS",
        "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_BACKGROUND_LOCATION"
    )

    private val STORES = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia",
        "com.xiaomi.mipicks", "com.heytap.market", "com.huawei.appmarket", "org.fdroid.fdroid"
    )

    fun scan(ctx: Context): ScanResult {
        val pm = ctx.packageManager
        val iocPkgs = HashSet<String>()
        val keywords = ArrayList<String>()
        loadIocs(ctx, iocPkgs, keywords)

        val launcher = launcherPackages(pm)
        val a11y = enabledPackages(ctx, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        val listeners = enabledPackages(ctx, "enabled_notification_listeners")
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admins = dpm.activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()

        val flags = ArrayList<AppFlag>()
        val packages = installed(pm)

        for (p in packages) {
            val ai = p.applicationInfo ?: continue
            val name = p.packageName
            if (name == ctx.packageName) continue
            val system = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            val label = pm.getApplicationLabel(ai).toString()
            val reasons = ArrayList<String>()
            var score = 0

            if (name in iocPkgs) {
                score += 10
                reasons.add("Package is on a public stalkerware indicator list")
            }
            val lower = "$name $label".lowercase()
            if (!system && keywords.any { lower.contains(it) }) {
                score += 3
                reasons.add("Name looks like a spy/monitoring app")
            }
            if (!system) {
                val sensitive = p.requestedPermissions?.count { it in SENSITIVE } ?: 0
                if (sensitive >= 4) {
                    score += 2
                    reasons.add("Requests $sensitive sensitive permissions (mic, camera, SMS, calls, contacts, location)")
                }
                if (name !in launcher && sensitive >= 2) {
                    score += 3
                    reasons.add("Hidden: no launcher icon, yet holds sensitive permissions")
                }
                if (name in a11y) {
                    score += 3
                    reasons.add("Has Accessibility access (can read your screen and typing)")
                }
                if (name in listeners) {
                    score += 2
                    reasons.add("Can read all your notifications")
                }
                if (name in admins) {
                    score += 3
                    reasons.add("Is a Device Administrator (hard to uninstall)")
                }
                val installer = installerOf(pm, name)
                if (installer == null || installer !in STORES) {
                    score += 1
                    reasons.add("Installed outside a major app store")
                }
            }
            if (score > 0) flags.add(AppFlag(name, label, score, reasons))
        }
        flags.sortByDescending { it.score }
        return ScanResult(flags, deviceChecks(ctx), packages.size)
    }

    private fun deviceChecks(ctx: Context): List<String> {
        val out = ArrayList<String>()
        val cr = ctx.contentResolver
        if (Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1)
            out.add("USB debugging (ADB) is on - someone with a cable could control the phone")
        if (Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1)
            out.add("Developer options are enabled")
        val su = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk", "/data/adb/magisk")
        if (su.any { File(it).exists() } || (Build.TAGS ?: "").contains("test-keys"))
            out.add("Phone looks rooted or runs a custom build")
        try {
            val patch = LocalDate.parse(Build.VERSION.SECURITY_PATCH)
            if (patch.isBefore(LocalDate.now().minusMonths(12)))
                out.add("Security patch is over 12 months old ($patch) - known exploits may work")
        } catch (e: Exception) {
        }
        return out
    }

    private fun loadIocs(ctx: Context, pkgs: HashSet<String>, kw: ArrayList<String>) {
        try {
            ctx.assets.open("iocs.txt").bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val l = raw.trim()
                    if (l.isEmpty() || l.startsWith("#")) continue
                    if (l.startsWith("kw:")) kw.add(l.removePrefix("kw:").lowercase()) else pkgs.add(l)
                }
            }
        } catch (e: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun installed(pm: PackageManager): List<PackageInfo> =
        if (Build.VERSION.SDK_INT >= 33)
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        else pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)

    @Suppress("DEPRECATION")
    private fun installerOf(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun launcherPackages(pm: PackageManager): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
    }

    private fun enabledPackages(ctx: Context, key: String): Set<String> {
        val s = Settings.Secure.getString(ctx.contentResolver, key) ?: return emptySet()
        return s.split(':').mapNotNull { ComponentName.unflattenFromString(it)?.packageName }.toSet()
    }
}
