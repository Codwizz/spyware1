# DeviceCheck (Android)

On-device scanner for stalkerware and spyware warning signs. No internet permission,
no server, nothing leaves the phone.

## What it checks
- Apps on public stalkerware indicator lists (added automatically at build time)
- Spy-style app names, hidden apps (no launcher icon) with sensitive permissions
- Apps with Accessibility, Notification-reading or Device Admin power
- Apps installed outside major app stores
- USB debugging, developer options, root signs, very old security patch

## Build and publish using only a phone
1. Make a free GitHub account, then create a new empty repository (for example `devicecheck`).
2. Add file -> Upload files -> upload `project.zip`, commit.
3. Add file -> Create new file. Name it `.github/workflows/build.yml`, paste the build.yml text, commit.
4. Open the Actions tab. The build runs by itself (about 5 minutes).
5. Open Releases, tap `DeviceCheck.apk`, install it (allow installs from your browser when asked).

Fix problems: if the Actions run shows a red cross, open it and send the error text to Claude.

## Limits
Finds common stalkerware and suspicious setups. It cannot detect advanced spyware
(Pegasus-class). For that use Amnesty's MVT (docs.mvt.re) or the Access Now helpline
(accessnow.org/help). iPhone does not allow any app to scan other apps.
